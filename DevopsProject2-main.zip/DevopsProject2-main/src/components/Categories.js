const abc = [
  { id: 0, name: "Action and Adventure" },
  { id: 1, name: "Anime" },
  { id: 2, name: "Comedy" },
  { id: 3, name: "Documentary" },
  { id: 4, name: "Drama" },
  { id: 5, name: "Fantasy" },
  { id: 6, name: "Horror" },
  { id: 7, name: "International" },
  { id: 8, name: "Kids" },
  { id: 9, name: "Music videos and concerts" },
  { id: 10, name: "Mystery and thrillers" },
  { id: 11, name: "Romance" },
];

export default abc;
